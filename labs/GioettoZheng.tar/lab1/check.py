# do not touch this file

# PART 1
MSE_train_correct_1 = 43.03370901982883
MSE_train_correct_2 = 37.852942066038246
MSE_train_correct_3 = 32.569639592369505
MSE_train_correct_4 = 32.257587947902685
MSE_test_correct_1 = 36.74870366001143
MSE_test_correct_2 = 33.504843402351156
MSE_test_correct_3 = 34.42512492881009
MSE_test_correct_4 = 35.38707250259879

# PART 2
accuracy_training_correct_1 = 0.890295358649789
accuracy_training_correct_m = 0.6751054852320675